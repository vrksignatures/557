package com.vrksignatures.aniwave;

import java.util.Arrays;
import java.util.List;

public class AdBlocker {
    private static final List<String> AD_KEYWORDS = Arrays.asList(
            "doubleclick.net", "googlesyndication", "googleadservices", "adservice.google",
            "popads", "popcash", "propellerads", "exoclick", "juicyads", "trafficjunky",
            "adsterra", "hilltopads", "clickadu", "admaven", "tsyndicate", "mc.yandex",
            "histats", "outbrain", "taboola", "mgid", "revcontent", "monetag",
            "acscdn", "onclkds", "bet365", "1xbet", "casino", "redirect"
    );

    public static boolean isAdUrl(String url) {
        if (url == null) return false;
        String lower = url.toLowerCase();
        for (String keyword : AD_KEYWORDS) {
            if (lower.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isStreamUrl(String url) {
        if (url == null) return false;
        String lower = url.toLowerCase();
        return (lower.contains(".m3u8") || lower.contains(".mp4"))
                && !lower.contains("favicon")
                && !isAdUrl(lower);
    }
}
